import React, { useEffect, useState } from 'react';
import './IndicativosDeVenda.css';
import ReactSpeedometer from 'react-d3-speedometer';
import axios from 'axios';
import api from '../../api';
import BarChartColaboradores from '../BarChart/BarChartColaboradores';

const Card = ({ title, title2, value, value2, subtitle, subtitle2, percentage, variation, icon }) => (
  <div className="indicativo-card">
    <div className="card-header">
      <h2>{title}</h2>
      {icon && <img src={icon} alt="Ícone" className="card-icon" />}
    </div>
    <div className="card-group">
      <p className="card-value">{value}</p>
      {subtitle && <p className="card-subtitle">{subtitle}</p>}
    </div>
    <div className="card-group">
      <p className="card-value">{value2}</p>
    </div>
    <div className="card-subtitle">
      {title2}
      {icon && <img src={icon} alt="Ícone" className="card-icon" />}
    </div>
    <div className="card-group">
      {percentage && <p className="card-percentage">{percentage}</p>}
      {subtitle2 && <p className="card-subtitle">{subtitle2}</p>}
    </div>
    {variation && <p className="card-variation"> {variation} Variação</p>}
  </div>
);

const IndicadoresCards = ({ periodoSelecionado, usarPDV }) => {
  const [loading, setLoading] = useState(false);

  const [peso, setPeso] = useState(null);
  const [pesoPercentual, setPesoPercentual] = useState(null);
  const [pesoVariacao, setPesoVariacao] = useState(null);
  const [pesoRealizado, setPesoRealizado] = useState(null);
  const [positivadoObjetivo, setPositivadoObjetivo] = useState('');
  const [positivadoRealizado, setPositivadoRealizado] = useState(null);
  const [positivadoPercentual, setPositivadoPercentual] = useState(null);
  const [positivadoVariacao, setPositivadoVariacao] = useState(null);
  const [vendaRealizada, setVendaRealizada] = useState(null);
  const [vendaPercentual, setVendaPercentual] = useState(null);
  const [vendaVariacao, setVendaVariacao] = useState(null);
  const [evolucaoAnoAnterior, setEvolucaoAnoAnterior] = useState(null);
  const [mixRealizado, setMixRealizado] = useState(null);
  const [mixPercentual, setMixPercentual] = useState(null);
  const [mixVariacao, setMixVariacao] = useState(null);
  const [objetivoFinanceiro, setObjetivoFinanceiro] = useState(null);
  const [objetivoMix, setObjetivoMix] = useState(null);
  const [alocacaoRealizada, setAlocacaoRealizada] = useState(null);
  const [alocacaoPrevenda, setAlocacaoPrevenda] = useState(null);
  const [alocacaoPercentual, setAlocacaoPercentual] = useState(null);
  const [alocacaoVariacao, setAlocacaoVariacao] = useState(null);
  const [vendaRealizadaBase, setVendaRealizadaBase] = useState(null);
  const [valorPDVBase, setValorPDVBase] = useState(null);
  const [vendaPDVFormatada, setVendaPDVFormatada] = useState(null);
  const [vendaTotalFormatada, setVendaTotalFormatada] = useState(null);
  const [pesoRealizadoBase, setPesoRealizadoBase] = useState(null);
  const [pesoPDVBase, setPesoPDVBase] = useState(null);
  const [pesoPDVFormatado, setPesoPDVFormatado] = useState(null);
  const [pesoTotalFormatado, setPesoTotalFormatado] = useState(null);
  const [valorAnoAnteriorBase, setValorAnoAnteriorBase] = useState(null);
  const [vendaPDVAnoAnterior, setVendaPDVAnoAnterior] = useState(null);
  const [evolucao_venda_vendapdv, setEvolucao_venda_vendapdv] = useState(null);
  const [modo, setModo] = useState('indicadores');

  useEffect(() => {
    const fetchIndicadores = async () => {
      const { de, ate } = periodoSelecionado;
      setValorPDVBase(null);
      setLoading(true);

      try {
        const token = localStorage.getItem('token');
        const response = await api.get(`http://localhost:8000/Indicadores/?de=${de}&ate=${ate}`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        const percentual = response.data.realizado_peso?.percentual || 0;
        const variacao = response.data.realizado_peso?.variacao || 0;
        const valor = response.data.objetivo?.objetivo_peso || 0;
        const realizado = response.data.vendas?.peso_realizado || 0;

        setPesoRealizado(realizado.toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
        setPeso(valor.toLocaleString('pt-BR'));
        setPesoPercentual(`${percentual.toFixed(2)}%`);
        setPesoVariacao(variacao.toLocaleString('pt-BR', { minimumFractionDigits: 2 }));

        const positivado = response.data.positivacao?.realizado || 0;
        const percentualPos = response.data.positivacao?.percentual || 0;
        const variacaoPos = response.data.positivacao?.variacao || 0;
        const objetivoPos = response.data.objetivo?.objetivo_positivacao || 0;

        setPositivadoObjetivo(objetivoPos.toLocaleString('pt-BR'));
        setPositivadoRealizado(positivado.toLocaleString('pt-BR'));
        setPositivadoPercentual(`${percentualPos.toFixed(2)}%`);
        setPositivadoVariacao(variacaoPos.toLocaleString('pt-BR'));

        const realizadoFinanceiro = response.data.realizado_financeiro || {};
        const valorVenda = realizadoFinanceiro.valor || 0;
        const percentualVenda = realizadoFinanceiro.percentual_cobertura || 0;
        const variacaoVenda = realizadoFinanceiro.variacao || 0;
        const evolucao = response.data.evolucao.percentual || 0;

        setVendaRealizada(valorVenda.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
        setVendaPercentual(`${percentualVenda.toFixed(2)}%`);
        setVendaVariacao(Math.abs(variacaoVenda).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
        setEvolucaoAnoAnterior(`${(evolucao).toFixed(2)}%`);

        const objetivoFin = response.data.objetivo?.financeiro || 0;
        const objetivoMixValor = response.data.objetivo?.objetivo_mix || 0;

        setObjetivoFinanceiro(objetivoFin.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
        setObjetivoMix(objetivoMixValor.toString());

        const realizadoMix = response.data.realizado_mix?.realizado || 0;
        const percentualMix = response.data.realizado_mix?.percentual || 0;
        const variacaoMix = response.data.realizado_mix?.variacao || 0;

        setMixRealizado(realizadoMix.toString());
        setMixPercentual(`${percentualMix.toFixed(2)}%`);
        setMixVariacao(variacaoMix.toString());

        const alocacao = response.data['pre-venda'] || {};
        const valorAlocado = alocacao.valor_alocado || 0;
        const valorPrevenda = alocacao.valor_prevenda || 0;
        const percentualAlocado = alocacao.percentual_prevenda_alocado || 0;
        const variacaoPrevenda = alocacao.variacao_prevenda || 0;

        setAlocacaoRealizada(valorAlocado.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
        setAlocacaoPrevenda(valorPrevenda.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
        setAlocacaoPercentual(`${percentualAlocado.toFixed(2)}%`);
        setAlocacaoVariacao(Math.abs(variacaoPrevenda).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));

        setVendaRealizadaBase(valorVenda);
        setPesoRealizado(realizado.toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
        setPesoRealizadoBase(realizado);

        const valorAnoAnterior = response.data.valor_ano_anterior || 0;
        setValorAnoAnteriorBase(valorAnoAnterior);
      } catch (error) {
        console.error('Erro ao buscar os indicadores:', error);
        setPeso('Erro');
      } finally {
        setLoading(false);
      }
    };

    if (periodoSelecionado?.de && periodoSelecionado?.ate) {
      fetchIndicadores();
    }
  }, [periodoSelecionado]);

  useEffect(() => {
    const atualizarValoresPDV = (valorPDV, pesoPDV) => {
      const novoValor = usarPDV ? vendaRealizadaBase + valorPDV : vendaRealizadaBase;

      setVendaRealizada(novoValor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));

      if (usarPDV) {
        setVendaPDVFormatada(valorPDV.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
        setVendaTotalFormatada(novoValor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
      } else {
        setVendaPDVFormatada(null);
        setVendaTotalFormatada(null);
      }

      const objetivoFin = parseFloat(objetivoFinanceiro?.replace(/[^\d,-]/g, '').replace(',', '.') || '0');
      const percentualCorrigido = objetivoFin ? (novoValor / objetivoFin) * 100 : 0;
      const variacaoCorrigida = novoValor - objetivoFin;

      setVendaPercentual(`${percentualCorrigido.toFixed(2)}%`);
      setVendaVariacao(Math.abs(variacaoCorrigida).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));

      const novoPeso = usarPDV ? pesoRealizadoBase + pesoPDV : pesoRealizadoBase;
      setPesoRealizado(novoPeso.toLocaleString('pt-BR', { minimumFractionDigits: 2 }));

      if (usarPDV) {
        setPesoPDVFormatado(pesoPDV.toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
        setPesoTotalFormatado(novoPeso.toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
      } else {
        setPesoPDVFormatado(null);
        setPesoTotalFormatado(null);
      }

      const objetivoPeso = parseFloat((peso || '0').replace(/[^\d,-]/g, '').replace(',', '.'));
      const percentualPeso = objetivoPeso ? (novoPeso / objetivoPeso) * 100 : 0;
      const variacaoPeso = novoPeso - objetivoPeso;

      setPesoPercentual(`${percentualPeso.toFixed(2)}%`);
      setPesoVariacao(variacaoPeso.toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
    };

    const fetchPDV = async () => {
      setLoading(true);
      try {
        const token = localStorage.getItem('token');
        const { de, ate } = periodoSelecionado;
        const responsePDV = await api.get(`http://localhost:8000/indicadores/pdv/?de=${de}&ate=${ate}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        const valorPDV = responsePDV.data.vendas_pdv?.venda_realizada || 0;
        const pesoPDV = responsePDV.data.vendas_pdv?.peso_realizado || 0;
        const vendaAnoAnterior = responsePDV.data.vendas_pdv?.venda_realizada_ano_anterior || 0;

        setValorPDVBase(valorPDV);
        setPesoPDVBase(pesoPDV);
        setVendaPDVAnoAnterior(vendaAnoAnterior);
        atualizarValoresPDV(valorPDV, pesoPDV);
      } catch (err) {
        console.error("Erro ao buscar vendas de PDV:", err);
      }
      setLoading(false);
    };

    if (vendaRealizadaBase === null || !periodoSelecionado?.de || !periodoSelecionado?.ate) return;

    if (usarPDV) {
      if (valorPDVBase != null && pesoPDVBase != null) {
        atualizarValoresPDV(valorPDVBase, pesoPDVBase);
      } else {
        fetchPDV();
      }
    } else {
      atualizarValoresPDV(valorPDVBase || 0, pesoPDVBase || 0);
    }
  }, [usarPDV, periodoSelecionado, vendaRealizadaBase, valorPDVBase, objetivoFinanceiro]);

  useEffect(() => {
    if (
      vendaRealizadaBase != null &&
      valorAnoAnteriorBase != null &&
      vendaPDVAnoAnterior != null
    ) {
      const somaAnoAnterior = valorAnoAnteriorBase + vendaPDVAnoAnterior;
      const percentual = somaAnoAnterior > 0 ? ((vendaRealizadaBase / somaAnoAnterior) * 100) - 100 : 0;
      setEvolucao_venda_vendapdv(`${percentual.toFixed(2)}%`);
    }
  }, [vendaRealizadaBase, valorAnoAnteriorBase, vendaPDVAnoAnterior]);


  return (
    
    <div style={{ position: 'relative' }}>
      {loading && (
        <div className="overlay-loader">
          <div className="spinner"></div>
        </div>
      )}
      <div className="modo-toggle">
      <button
        onClick={() => setModo('indicadores')}
        className={modo === 'indicadores' ? 'ativo-indicadores' : ''}
      >
        🎯 Indicadores
      </button>

      <button
        onClick={() => setModo('graficos')}
        className={modo === 'graficos' ? 'ativo-graficos' : ''}
      >
        📊 Graficos
      </button>
    </div>
      {modo === 'graficos' ? (
  <div className="dashboard-graficos">
    <h2>Velocímetros de Meta</h2>

    <div style={{ display: 'flex', gap: '2rem', flexWrap: 'wrap' }}>
      
            <div>
        <h4>Venda</h4>
        <ReactSpeedometer
          maxValue={100}
          value={parseFloat((vendaPercentual || '0').replace('%', ''))}
          segments={5}
          height={160}
        />
      </div>

      
      <div>
        <h4>Peso</h4>
        <ReactSpeedometer
          maxValue={100}
          value={parseFloat((pesoPercentual || '0').replace('%', ''))}
          segments={5}
          height={160}
        />
      </div>

      <div>
        <h4>Positivação</h4>
        <ReactSpeedometer
          maxValue={100}
          value={parseFloat((positivadoPercentual || '0').replace('%', ''))}
          segments={5}
          height={160}
        />
      </div>
    </div>
  </div>
) : (
      <div className="indicativos-container">
        <div className="indicativo-stack">
          <Card title="Objetivo (R$)" value={objetivoFinanceiro ?? '...'} />
          <Card title="Evo % vs Ano Ant." value={evolucao_venda_vendapdv ?? evolucaoAnoAnterior ?? '...'} />
        </div>

      <Card
        title="Venda Realizada"
        value={
          usarPDV
            ? (
                <>
                  <div>{vendaRealizadaBase?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</div>
                  <div>PDV: {vendaPDVFormatada}</div>
                  <div>Total: {vendaTotalFormatada}</div>
                </>
              )
            : vendaRealizada
        }
        subtitle="Faturamento"
        percentage={vendaPercentual ?? '...'}
        subtitle2=" Cobertura Atual"
        variation={vendaVariacao ?? '...'}
      />

      <Card
        title="Alocações"
        value={alocacaoRealizada ?? '...'}
        subtitle="Fat + A Faturar"
        title2="Pré-Venda"
        value2={alocacaoPrevenda ?? '...'}
        percentage={alocacaoPercentual ?? '...'}
        subtitle2=" Cobertura Prevista"
        variation={alocacaoVariacao ?? '...'}
      />
      <Card
        title="Captado"
        value="0"
        subtitle="Valor Captado"
        percentage="0%"
        subtitle2=" Cobertura"
        variation="0"
      />
      <Card
        title="Peso"
        value={peso ?? '...'}
        subtitle="OBJETIVO KG"
        title2="Realizado KG"
        value2={
          usarPDV
            ? (
                <>
                  <div>{pesoRealizadoBase?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
                  <div>PDV: {pesoPDVFormatado}</div>
                  <div>Total: {pesoTotalFormatado}</div>
                </>
              )
            : pesoRealizado ?? '...'
        }
        percentage={pesoPercentual}
        subtitle2=" Cobertura"
        variation={pesoVariacao}
      />

      <Card
        title="Positivado"
        value={positivadoObjetivo  ?? '...'}
        subtitle="OBJETIVO"
        value2={positivadoRealizado ?? '...'}
        title2="Realizado"
        percentage={positivadoPercentual}
        subtitle2=" Cobertura"
        variation={positivadoVariacao}
      />
      <Card
        title="MIX"
        value={objetivoMix ?? '...'}
        subtitle="OBJETIVO"
        value2={mixRealizado ?? '--'}
        title2="Realizado"
        percentage={mixPercentual ?? '--'}
        subtitle2=" Cobertura"
        variation={mixVariacao ?? '...'}
      />
            
    </div>
)}
    </div>
  );
};

export default IndicadoresCards;
